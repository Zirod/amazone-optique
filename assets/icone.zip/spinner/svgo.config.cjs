module.exports = {
  plugins: [
    // Other plugins can be added here if needed
  ],
};
